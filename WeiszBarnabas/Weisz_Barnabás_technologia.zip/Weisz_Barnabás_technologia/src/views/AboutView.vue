<template>
    
    <div id="logo">
        <img class="biglogo" src="../assets/Jedlik_big.png" alt="Jedlik logo">
        <p class="felirat">Jedlik Ányos technikum - Győr</p>
    </div>
    <footer class="bg-primary">
        <p class="text-center text-white fs-3"></p>
    </footer>
</template>

<script setup>
import { ref } from 'vue';
import dataservice from '../services/dataservice';




</script>